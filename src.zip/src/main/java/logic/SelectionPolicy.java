package logic;

public enum SelectionPolicy {
    TIMESTRATEGY, SHORTESTQUEUESTRATEGY
}
